Fog Of War Tool Read Me

V1.0, 5/31/2019
by Mike Barker

PLEASE read this entire guide, especially the "Limitations and Bugs"

General Usage:
After startup, the user will be presented with a blank surface. Typically, you will want to load whatever
map (world, dungeon, or otherwise) via File->Open Image
The image will then be displayed on the canvas. The "Background Stretch" settings menu might be useful
to tweak how it displays.
All that must be done now is click on the canvas to draw polygons to cover the map like small scraps of paper.
The polygons can be of any shape or size. If you mis-place a point or line, hit ESC to cancel the current draw.
If you wish to destroy a polygon that has been created, click "Erase" then the polygon.

Once all the polygons are created (or you are out of time) you can save your work with File->Save Project.

Border Settings:
These allow for the edges of the polygons to be highlit for the player or GM. The default behavior is to
only have the GM see the borders. These will also persist on the GM's view in case they must re-hide or 
re-show a polygon.

Background Stretch:
After loading the background image(s), try using the different settings to get the desired image stretch.

Player Display
The Player Display is enabled by Player Window->Spawn Player Window. To set its backgroung (which can be totally
different from the GM's background for annotated maps or whatever), click Player Window->Set Player Image.

Note that the Player Display is mostly non-interactive. All operations are through the GM's window except 
the red position flag (see below).

Position Flag
There is a red flag in the upper left of both the GM and Player's window. This can be moved in either window
but moving it on the GM's surface moves it in both windows.
#######################

Game Mode:
Toggle this setting when it is time to use the tool on 'game day'. In "Game Mode", you cannot draw polygons. 
Clicking on a polygon will cause it to become invisible. However, the polygon still exists (it is merely
invisible) so clicking on it again will cause it to reappear. TIP: To emphaisize a section of the map, the 
GM/DM can rapidly click on a polygon to create a 'blinking' effect.

#######################
Limitations and Bugs

WARNING: The system does NOT periodically save your work or prompt you to save upon exit. SAVE OFTEN!

Bug: Closing the GM/Master window does not close the Player window, effectively orphaning it. This 
will be fixed in the future. For now, just close the other window manually.

Bug: It requires multiple clicks to place a point while drawing a polygon. The investigation of this bug
is ongoing. It seems the canvas control sometimes has trouble "hearing" the mouse clicks. The problem
appears worse on slower or older hardware. The bug never manifests during game mode (so far), thus
its believed that there is some relation to drawing the lines (including the dynamic line) and hearing
the clicks.
